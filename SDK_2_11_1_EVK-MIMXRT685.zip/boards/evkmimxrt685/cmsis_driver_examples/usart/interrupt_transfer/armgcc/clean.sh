#!/bin/sh
rm -rf debug release flash_debug flash_release CMakeFiles
rm -rf Makefile cmake_install.cmake CMakeCache.txt
